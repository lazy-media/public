BFGMiner:
St. Barbara's Faithfully Glorified Mining Initiative Naturally Exceeding Rivals
or Basically a Freaking Good Miner

This is a multi-threaded, multi-blockchain, multi-pool ASIC, FPGA, GPU and CPU
miner with dynamic clocking, monitoring, and fanspeed support for bitcoin.

This code is provided entirely free of charge by the programmer in his spare
time so donations would be greatly appreciated. Please consider donating to the
address below.

Luke-Jr <luke-jr+bfgminer@utopios.org>
1QATWksNFGeUJCWBrN4g6hGM178Lovm7Wh

DOWNLOADS:

http://luke.dashjr.org/programs/bitcoin/files/bfgminer

GIT TREE:

https://github.com/luke-jr/bfgminer

Bug reports:

https://github.com/luke-jr/bfgminer/issues

IRC Channel:

irc://irc.freenode.net/eligius

License: GPLv3.  See COPYING for details.

SEE ALSO README.ASIC, README.FPGA, README.GPU, README.RPC, AND README.scrypt FOR
MORE INFORMATION ON EACH.

---

EXECUTIVE SUMMARY ON USAGE:

Single pool:

bfgminer -o http://pool:port -u username -p password

Multiple pools:

bfgminer -o http://pool1:port -u pool1username -p pool1password -o http://pool2:port -u pool2usernmae -p pool2password

Multiple blockchains:

bfgminer -o http://pool1:port -u pool1username -p pool1password --pool-goal default -o http://pool2:port -u pool2usernmae -p pool2password --pool-goal freicoin

Single pool with a standard http proxy:

bfgminer -o http://pool:port -x http://proxy:port -u username -p password

Single pool with a socks5 proxy:

bfgminer -o http://pool:port -x socks5://proxy:port -u username -p password

The list of proxy types are:
 http:    standard http 1.1 proxy
 socks4:  socks4 proxy
 socks5:  socks5 proxy
 socks4a: socks4a proxy
 socks5h: socks5 proxy using a hostname

Proxy support requires cURL version 7.21.7 or newer.

If you specify the --socks-proxy option to BFGMiner, it will only be applied to
all pools that don't specify their own proxy setting like above


After saving configuration from the menu ([S],[W]) you do not need to give
BFGMiner any arguments, it will load your configuration instead.

Any configuration file may also contain a single
	"include" : "filename"
to recursively include another configuration file.
Writing the configuration will save all settings from all files to the output
configuration file.


---
BUILDING BFGMINER

Everything you probably want, condensed:
	build-essential autoconf automake libtool pkg-config libcurl4-gnutls-dev
	libjansson-dev uthash-dev libncursesw5-dev libudev-dev libusb-1.0-0-dev
	libevent-dev libmicrohttpd-dev hidapi

Dependencies:
	autoconf             http://www.gnu.org/software/autoconf/
	automake             http://www.gnu.org/software/automake/
	libtool              http://www.gnu.org/software/libtool/
	pkg-config           http://www.freedesktop.org/wiki/Software/pkg-config
	...or pkgconf        https://github.com/pkgconf/pkgconf

	libcurl4-gnutls-dev  http://curl.haxx.se/libcurl/

	libjansson-dev 2.0+  http://www.digip.org/jansson/
	
	uthash-dev 1.9.4+    http://troydhanson.github.io/uthash/

Optional Dependencies:
	Text-User-Interface (TUI): curses dev library; any one of:
	  libncurses5-dev    http://www.gnu.org/software/ncurses/ (Linux and Mac)
	  libncursesw5-dev       ^ same
	  libpdcurses        http://pdcurses.sourceforge.net/ (Linux/Mac/Windows)

	Multiple ASIC/FPGA autodetection: any one of:
	  sysfs              (built-in to most Linux kernels, just mount on /sys)
	  libudev-dev        http://www.freedesktop.org/software/systemd/libudev/
	
	HashBuster Nano & NanoFury USB devices:
	  hidapi             https://github.com/signal11/hidapi
	
	getwork server for Block Erupter Blades:
	  libmicrohttpd-dev 0.9.5+  http://www.gnu.org/software/libmicrohttpd/
	
	Stratum proxy:
	  libevent 2.0.3+    http://libevent.org/

	HashBuster Micro, Klondike, X6500 and ZTEX FPGA boards:
	  libusb-1.0-0-dev   http://www.libusb.org/

	Video card GPU mining (free):
	  llvm 3.3+          http://llvm.org/
	  clang 3.3+         http://clang.llvm.org/
	  libclc             http://libclc.llvm.org/
	  Mesa 9.2.0+        http://www.mesa3d.org/
	
	ATi/AMD video card GPU mining (non-free):
	  AMD APP SDK        http://developer.amd.com/tools/heterogeneous-computing/amd-accelerated-parallel-processing-app-sdk/

	CPU mining optimized assembly algorithms:
	  yasm 1.0.1+        http://yasm.tortall.net/


BFGMiner driver configuration options:
	--disable-other-drivers Build without drivers by default unless explicitly
	                        enabled
	--enable-broad-udevrules
	                        Include udev rules for ambiguous devices which may
	                        not be miners
	--disable-avalon        Compile support for Avalon (default enabled)
	--disable-avalonmm      Compile support for Avalon2/3 (default enabled)
	--enable-bfsb           Compile support for BFSB (default disabled)
	--disable-bfx           Compile support for BFx2 (default enabled)
	--disable-bifury        Compile support for Bi*Fury (default enabled)
	--disable-bigpic        Compile support for Big Picture Mining USB (default
	                        enabled)
	--disable-bitforce      Compile support for BitForce (default enabled)
	--disable-bitfury       Compile support for Bitfury (default enabled)
	--disable-cointerra     Compile support for CoinTerra (default enabled)
	--enable-cpumining      Compile support for CPU mining (default disabled)
	--disable-drillbit      Compile support for DrillBit (default enabled)
	--disable-dualminer     Compile support for DualMiner (default enabled)
	--disable-gridseed      Compile support for GridSeed (default enabled)
	--disable-hashbuster    Compile support for HashBuster Nano (default
	                        enabled)
	--disable-hashbusterusb Compile support for HashBuster Micro (default
	                        enabled)
	--disable-hashfast      Compile support for HashFast (default enabled)
	--disable-icarus        Compile support for Icarus (default enabled)
	--enable-jingtian       Compile support for JingTian (default disabled)
	--disable-klondike      Compile support for Klondike (default enabled)
	--enable-knc            Compile support for KnC (default disabled)
	--enable-kncasic        Compile support for KnC gen 2 (default disabled)
	--disable-littlefury    Compile support for LittleFury (default enabled)
	--enable-metabank       Compile support for Metabank (default disabled)
	--enable-minergate      Compile support for Spondoolies minergate interface
	                        (default disabled)
	--enable-minion         Compile support for Minion (default disabled)
	--disable-modminer      Compile support for ModMiner (default enabled)
	--disable-nanofury      Compile support for NanoFury (default enabled)
	--enable-opencl         Compile support for OpenCL (default disabled)
	--disable-adl           Build without ADL monitoring (default enabled)
	--disable-rockminer     Compile support for RockMiner (default enabled)
	--enable-titan          Compile support for KnC Titan (default disabled)
	--disable-twinfury      Compile support for Twinfury (default enabled)
	--disable-x6500         Compile support for X6500 (default enabled)
	--disable-zeusminer     Compile support for ZeusMiner (default enabled)
	--disable-ztex          Compile support for ZTEX (default enabled)

BFGMiner algorithm configuration option:
	--enable-keccak         Compile support for Keccak (default disabled)
	--disable-sha256d       Compile support for SHA256d (default enabled)
	--enable-scrypt         Compile support for scrypt (default disabled)

BFGMiner dependency configuration options:
	--without-curses        Compile support for curses TUI (default enabled)
	--without-libevent      Compile support for libevent stratum server (default
	                        enabled)
	--without-libmicrohttpd Compile support for libmicrohttpd getwork server
	                        (default enabled)
	--without-libudev       Autodetect FPGAs using libudev (default enabled)
	--without-libusb        Compile using libusb (default enabled)
	--without-sensors       Build with libsensors monitoring (default enabled)
	--with-system-libblkmaker
	                        Use system libblkmaker rather than bundled one
	                        (default disabled)
	--with-udevrulesdir=DIR Install udev rules into this directory
	--with-udevrules-group=groupname
	                        Configure mining devices to be owned by a specific
	                        group (default `video')
	--without-uio           Compile support for PCI devices via Linux UIO
	                        interface (default enabled)
	--without-vfio          Compile support for PCI devices via Linux VFIO
	                        interface (default enabled)

Basic *nix build instructions:

./autogen.sh    # only needed if building from git repo
./configure  # list configuration options here
make

No installation is necessary. You may run BFGMiner from the build directory
directly.

On Mac OS X, you can use Homebrew to install the dependency libraries. When you
are ready to build BFGMiner, you may need to point the configure script at one
or more pkg-config paths. For example:
	./configure PKG_CONFIG_PATH=/usr/local/opt/curl/lib/pkgconfig:/usr/local/opt/jansson/lib/pkgconfig

Native WIN32 build instructions: see windows-build.txt

If you build BFGMiner from source, it is recommended that you run it from the
build directory. On *nix, you will usually need to prepend your command with a
path like this (if you are in the bfgminer directory already): ./bfgminer
To install system wide run 'sudo make install' or 'make install' as root. You
can then run from any terminal.

---

Usage instructions:  Run "bfgminer --help" to see options:

Usage: bfgminer [-DdElmpPQqUsTouOchnV]

Options for both config file and command line:
--api-allow         Allow API access (if enabled) only to the given list of [W:]IP[/Prefix] address[/subnets]
                    This overrides --api-network and you must specify 127.0.0.1 if it is required
                    W: in front of the IP address gives that address privileged access to all api commands
--api-description   Description placed in the API status header (default: BFGMiner version)
--api-groups        API one letter groups G:cmd:cmd[,P:cmd:*...]
                    See README.RPC for usage
--api-listen        Listen for API requests (default: disabled)
                    By default any command that does not just display data returns access denied
                    See --api-allow to overcome this
--api-mcast         Enable API Multicast listener, default: disabled
--api-mcast-addr <arg> API Multicast listen address (default: "224.0.0.75")
--api-mcast-code <arg> Code expected in the API Multicast message, don't use '-' (default: "FTW")
--api-mcast-des <arg>  Description appended to the API Multicast reply, default: ''
--api-mcast-port <arg> API Multicast listen port (default: 4028)
--api-network       Allow API (if enabled) to listen on/for any address (default: only 127.0.0.1)
--api-port          Port number of miner API (default: 4028)
--balance           Change multipool strategy from failover to even share balance
--benchmark         Run BFGMiner in benchmark mode - produces no shares
--benchmark-intense Run BFGMiner in intensive benchmark mode - produces no shares
--chroot-dir <arg>  Chroot to a directory right after startup
--cmd-idle <arg>    Execute a command when a device is allowed to be idle (rest or wait)
--cmd-sick <arg>    Execute a command when a device is declared sick
--cmd-dead <arg>    Execute a command when a device is declared dead
--coinbase-check-addr <arg> A list of address to check against in coinbase payout list received from the previous-defined pool, separated by ','
--coinbase-check-total <arg> The least total payout amount expected in coinbase received from the previous-defined pool
--coinbase-check-percent <arg> The least benefit percentage expected for the sum of addr(s) listed in --cbaddr argument for previous-defined pool
--coinbase-sig <arg> Set coinbase signature when possible
--compact           Use compact display without per device statistics
--debug|-D          Enable debug output
--debuglog          Enable debug logging
--device-protocol-dump Verbose dump of device protocol-level activities
--device|-d <arg>   Enable only devices matching pattern (default: all)
--disable-rejecting Automatically disable pools that continually reject shares
--http-port <arg>   Port number to listen on for HTTP getwork miners (-1 means disabled) (default: -1)
--expiry <arg>      Upper bound on how many seconds after getting work we consider a share from it stale (w/o longpoll active) (default: 120)
--expiry-lp <arg>   Upper bound on how many seconds after getting work we consider a share from it stale (with longpoll active) (default: 3600)
--failover-only     Don't leak work to backup pools when primary pool is lagging
--failover-switch-delay <arg> Delay in seconds before switching back to a failed pool (default: 300)
--generate-to <arg> Set an address to generate to for solo mining
--force-dev-init    Always initialize devices when possible (such as bitstream uploads to some FPGAs)
--kernel-path <arg> Specify a path to where bitstream and kernel files are
--load-balance      Change multipool strategy from failover to quota based balance
--log|-l <arg>      Interval in seconds between log output (default: 20)
--log-file|-L <arg> Append log file for output messages
--log-microseconds  Include microseconds in log output
--monitor|-m <arg>  Use custom pipe cmd for output messages
--net-delay         Impose small delays in networking to avoid overloading slow routers
--no-gbt            Disable getblocktemplate support
--no-getwork        Disable getwork support
--no-hotplug        Disable hotplug detection
--no-local-bitcoin  Disable adding pools for local bitcoin RPC servers
--no-longpoll       Disable X-Long-Polling support
--no-pool-redirect  Ignore pool requests to redirect to another server
--no-restart        Do not attempt to restart devices that hang
--no-stratum        Disable Stratum detection
--no-submit-stale   Don't submit shares if they are detected as stale
--no-unicode        Don't use Unicode characters in TUI
--noncelog <arg>    Create log of all nonces found
--pass|-p <arg>     Password for bitcoin JSON-RPC server
--per-device-stats  Force verbose mode and output per-device statistics
--pool-goal <arg>   Named goal for the previous-defined pool
--pool-priority <arg> Priority for just the previous-defined pool
--pool-proxy|-x     Proxy URI to use for connecting to just the previous-defined pool
--protocol-dump|-P  Verbose dump of protocol-level activities
--queue|-Q <arg>    Minimum number of work items to have queued (0 - 10) (default: 1)
--quiet|-q          Disable logging output, display status and errors
--quit-summary <arg> Summary printed when you quit: none/devs/procs/detailed
--quota|-U <arg>    quota;URL combination for server with load-balance strategy quotas
--real-quiet        Disable all output
--request-diff <arg> Request a specific difficulty from pools (default: 1.0)
--retries <arg>     Number of times to retry failed submissions before giving up (-1 means never) (default: -1)
--rotate <arg>      Change multipool strategy from failover to regularly rotate at N minutes (default: 0)
--round-robin       Change multipool strategy from failover to round robin on failure
--scan|-S <arg>     Configure how to scan for mining devices
--scan-time <arg>   Upper bound on time spent scanning current work, in seconds (default: 60)
--sched-start <arg> Set a time of day in HH:MM to start mining (a once off without a stop time)
--sched-stop <arg>  Set a time of day in HH:MM to stop mining (will quit without a start time)
--scrypt            Use the scrypt algorithm for mining (non-bitcoin)
--set-device|--set <arg> Set default parameters on devices; eg, NFY:osc6_bits=50
--setuid <arg>      Username of an unprivileged user to run as
--sharelog <arg>    Append share log to file
--shares <arg>      Quit after mining 2^32 * N hashes worth of shares (default: unlimited)
--show-processors   Show per processor statistics in summary
--skip-security-checks <arg> Skip security checks sometimes to save bandwidth; only check 1/<arg>th of the time (default: never skip)
--socks-proxy <arg> Set socks proxy (host:port) for all pools without a proxy specified
--stratum-port <arg> Port number to listen on for stratum miners (-1 means disabled) (default: -1)
--submit-threads    Minimum number of concurrent share submissions (default: 64)
--syslog            Use system log for output messages (default: standard error)
--temp-hysteresis <arg> Set how much the temperature can fluctuate outside limits when automanaging speeds (default: 3)
--text-only|-T      Disable ncurses formatted screen output
--unicode           Use Unicode characters in TUI
--url|-o <arg>      URL for bitcoin JSON-RPC server
--user|-u <arg>     Username for bitcoin JSON-RPC server
--verbose           Log verbose output to stderr as well as status output
--weighed-stats     Display statistics weighed to difficulty 1
--userpass|-O <arg> Username:Password pair for bitcoin JSON-RPC server
--worktime                     Display extra work time debug information
Options for command line only:
--config|-c <arg>   Load a JSON-format configuration file
See example.conf for an example configuration.
--no-default-config Inhibit loading default config file
--default-config    Always load the default config file
--help|-h           Print this message
--version|-V        Display version and exit


GPU only options:

--gpu-map <arg>     Map OpenCL to ADL device order manually, paired CSV (e.g. 1:0,2:1 maps OpenCL 1 to ADL 0, 2 to 1)
--gpu-platform <arg> Select OpenCL platform ID to use for GPU mining
--gpu-reorder       Attempt to reorder GPU devices according to PCI Bus ID
--no-adl            Disable the ATI display library used for monitoring and setting GPU parameters

GPU mining is disabled by default for SHA256d if you have any dedicated mining
devices, but can be enabled explicitly specifying the -S opencl:auto option.

See README.GPU for more information regarding GPU mining.
See README.scrypt for more information regarding (non-bitcoin) scrypt mining.


To use ASICs or FPGAs, you will need to be sure the user BFGMiner is running as
has appropriate permissions. This varies by operating system.
On Linux, with BFGMiner's udev rules: sudo usermod <username> -a -G video
Note that on GNU/Linux systems, you will usually need to login again before
group changes take effect.

By default, BFGMiner will scan for autodetected devices. If you want to prevent
BFGMiner from doing this, you can use "-S noauto". If you want to probe all
serial ports, you can use "-S all"; note that this may write data to non-mining
devices which may then behave in unexpected ways!

On Linux, <arg> is usually of the format /dev/ttyUSBn
On Mac OS X, <arg> is usually of the format /dev/cu.usb*
On Windows, <arg> is usually of the format \\.\COMn
(where n = the correct device number for the device)

The official supplied binaries are compiled with support for all ASICs/FPGAs.
To force the code to only attempt detection with a specific driver,
prepend the argument with the driver name followed by an "at" symbol.
For example, "icarus@/dev/ttyUSB0" or "bitforce@\\.\COM5"
or using the short name: "ica@/dev/ttyUSB0" or "bfl@\\.\COM5"

Some FPGAs do not have non-volatile storage for their bitstreams and must be
programmed every power cycle, including first use. To use these devices, you
must download the proper bitstream from the vendor's website and copy it to the
"bitstreams" directory into your BFGMiner application directory.

See README.ASIC and README.FPGA for more information regarding these.

See README.CPU for information regarding CPU mining.

---

WHILE RUNNING:

The following options are available while running with a single keypress:

[M]anage devices [P]ool management [S]ettings [D]isplay options  [H]elp [Q]uit

M gives you something like:

Select processor to manage using up/down arrow keys
 BFL 0a: 78.0C |  3.64/ 3.70/ 2.91Gh/s | A:46 R:0+0(none) HW:  2/none
  BitFORCE SHA256 SC from Butterfly Labs
Serial: FTWN6T67

[D]isable
Or press Enter when done


P gives you:

Current pool management strategy: Failover
[F]ailover only disabled
[A]dd pool [R]emove pool [D]isable pool [E]nable pool
[C]hange management strategy [S]witch pool [I]nformation


S gives you:

[L]ongpoll: On
[Q]ueue: 1
[S]cantime: 60
[E]xpiry: 120
[R]etries: -1
[W]rite config file
[B]FGMiner restart


D gives you:

[N]ormal [C]lear [S]ilent mode (disable all output)
[D]ebug:off
[P]er-device:off
[Q]uiet:off
[V]erbose:off
[R]PC debug:off
[W]orkTime details:off
co[M]pact: off
[L]og interval:5


Q quits the application.


The running log shows output similar to that below:

 [2013-02-13 00:26:30] Accepted 1758e8df BFL 0  pool 0 Diff 10/1
 [2013-02-13 00:26:32] Accepted 1d9a2199 MMQ 0a pool 0 Diff 8/1
 [2013-02-13 00:26:33] Accepted b1304924 ZTX 0  pool 0 Diff 1/1
 [2013-02-13 00:26:33] Accepted c3ad22f4 XBS 0b pool 0 Diff 1/1

The 8 byte hex value are the 2nd set of 32 bits from the share submitted to the
pool. The 2 diff values are the actual difficulty target that share reached
followed by the difficulty target the pool is currently asking for.

---
Also many issues and FAQs are covered in the forum threads
dedicated to this program,
	https://bitcointalk.org/?topic=78192
	https://bitcointalk.org/?topic=168174

If you are mining on a single pool, the pool display shows:
 Pool 0: ...s.m.eligius.st   Diff:16  +Strtm  LU:[03:26:16]  User:1QATWksNFGeUJCWBrN4g6hGM178Lovm7Wh

This tells you which pool you're using, as well as its current share difficulty,
protocol, and last explicit work update. If BFGMiner has a working block
notification source, the protocol will be prefixed by a plus sign. If not, a
minus sign.

If you are mining on multiple pools at once, the pool display instead shows:
 Pools: 2 (0,1)              Diff:4-16  +  LU:[03:25:30]

You get the total number of working pools, the pool numbers for each of those,
the range of current share difficulties, whether block notification is working
(plus/minus), and the oldest explicit work update currently being used for new
work.

The block display shows:
Block #217364: ...1b89f8d3  Diff:7.67M (54.93T)  Started: [17:17:22]  I:12.99mBTC/hr

This shows a short stretch of the next block's height, the current block,
difficulty (including the network hashrate that difficulty represents), when the
search for the new block started, and finally expected Income, calculated by
actual shares submitted in 100% PPS value (assumes Bitcoin, does not account for
altcoin conversions!).

The BFGMiner status line shows:
 ST:1  F:0  NB:1  AS:0  BW:[ 75/241 B/s]  E:2.42  BS:2.71k

ST is STaged work items (ready to use).
F  is network Failure occasions (server down or slow to provide work)
NB is New Blocks detected on the network
AS is Active Submissions (shares in the process of submitting)
BW is BandWidth usage on the network (received/sent)
E  is Efficiency defined as number of shares accepted (multiplied by their
          difficulty) per 2 KB of bandwidth
BS is the all time Best Share difficulty you've found

The totals line shows the following:
 6/32   75.0C | 171.3/170.8/171.2Gh/s | A:729 R:8+0(.01%) HW:0/.81%

Each column is as follows:
  The number of devices and processors currently mining
  Hottest temperature reported by any processor
  20 second exponentially decaying average hash rate (configurable with --log
      option)
  An all time average hash rate
  An all time average hash rate based on actual nonces found, adjusted for pool
      reject and stale rate
  The number of Accepted shares
  The number of Rejected shares and stale shares discarded (never submitted),
      and the percentage these are of total found.
  The number of HardWare errors, and percentage invalid of nonces returned

Each device shows:
 BFL 2: 74.0C | 51.97/58.90/57.17Gh/s | A:847 R:15+0(.54%) HW:496/.91%

Columns are the same as in the totals line.


---
MULTIPOOL

FAILOVER STRATEGIES WITH MULTIPOOL:
A number of different strategies for dealing with multipool setups are
available. Each has their advantages and disadvantages so multiple strategies
are available by user choice, as per the following list:

FAILOVER:
The default strategy is failover. This means that if you input a number of
pools, it will try to use them as a priority list, moving away from the 1st
to the 2nd, 2nd to 3rd and so on. If any of the earlier pools recover, it will
move back to the higher priority ones.

ROUND ROBIN:
This strategy only moves from one pool to the next when the current one falls
idle and makes no attempt to move otherwise.

ROTATE:
This strategy moves at user-defined intervals from one active pool to the next,
skipping pools that are idle.

LOAD BALANCE:
This strategy sends work to all the pools on a quota basis. By default, all
pools are allocated equal quotas unless specified with --quota. This
apportioning of work is based on work handed out, not shares returned so is
independent of difficulty targets or rejected shares. While a pool is disabled
or dead, its quota is dropped until it is re-enabled. Quotas are forward
looking, so if the quota is changed on the fly, it only affects future work.
If all pools are set to zero quota or all pools with quota are dead, it will
fall back to a failover mode. See quota below for more information.

The failover-only flag has special meaning in combination with load-balance
mode and it will distribute quota back to priority pool 0 from any pools that
are unable to provide work for any reason so as to maintain quota ratios
between the rest of the pools.

BALANCE:
This strategy monitors the amount of difficulty 1 shares solved for each pool
and uses it as a basis for trying to doing the same amount of work for each
pool.


---
SOLO MINING

BFGMiner supports solo mining with any GBT-compatible bitcoin node (such as
bitcoind). To use this mode, you need to specify the URL of your bitcoind node
using the usual pool options (--url, --userpass, etc), and the --generate-to
option to specify the Bitcoin address you wish to receive the block rewards
mined. When you run Bitcoin Core on the same computer as your miner, the pool
itself will be automatically configured for you (on the default goal). Please be
aware that solo mining via GBT is at this time only supported for Bitcoin.

IMPORTANT: If you are solo mining with more than one instance of BFGMiner (or
any other software) per payout address, you must also specify data using the
--coinbase-sig option to ensure each miner is working on unique work. Note
that this data will be publicly seen if your miner finds a block using any
GBT-enabled pool, even when not solo mining (such as failover).

If your bitcoin node does not support longpolling (for example, bitcoind 0.8.x),
you should consider setting up a failover pool to provide you with block
notifications. Note that solo mining does not use shares, so BFGMiner's adjusted
hashrate (third column) may suddenly drop to zero if a block you submit is
rejected; this does not indicate that it has stopped mining.

Example solo mining usage:

bfgminer -o http://localhost:8332 -u username -p password \
    --generate-to 1QATWksNFGeUJCWBrN4g6hGM178Lovm7Wh \
    --coinbase-sig "rig1: This is Joe's block!"

If you want to solo mine on multiple GBT-compatible Bitcoin blockchains, you can
specify --generate-to multiple times with a goal name prefix followed by a
colon. Note that at this time, the coinbase sig is always shared across all
goals/pools.

Example multi-blockchain solo mining usage:

bfgminer -o http://localhost:8332 -u username -p password \
    --generate-to 1QATWksNFGeUJCWBrN4g6hGM178Lovm7Wh \
    -o http://localhost:7221 -u user2 -p password --pool-goal mychain \
    --generate-to mychain:1QATWksNFGeUJCWBrN4g6hGM178Lovm7Wh \
    --coinbase-sig "rig1: This is Joe's block!"


---
QUOTAS

The load-balance multipool strategy works off a quota based scheduler. The
quotas handed out by default are equal, but the user is allowed to specify any
arbitrary ratio of quotas. For example, if all the quota values add up to 100,
each quota value will be a percentage, but if 2 pools are specified and pool0
is given a quota of 1 and pool1 is given a quota of 9, pool0 will get 10% of
the work and pool1 will get 90%. Quotas can be changed on the fly with RPC,
and do not act retrospectively. Setting a quota to zero will effectively
disable that pool unless all other pools are disabled or dead. In that
scenario, load-balance falls back to regular failover priority-based strategy.
While a pool is dead, it loses its quota and no attempt is made to catch up
when it comes back to life.

To specify quotas on the command line, pools should be specified with a
semicolon separated --quota(or -U) entry instead of --url. Pools specified with
--url are given a nominal quota value of 1 and entries can be mixed.

For example:
--url poolA:portA -u usernameA -p passA --quota "2;poolB:portB" -u usernameB -p passB
Will give poolA 1/3 of the work and poolB 2/3 of the work.

Writing configuration files with quotas is likewise supported. To use the above
quotas in a configuration file they would be specified thus:

"pools" : [
        {
                "url" : "poolA:portA",
                "user" : "usernameA",
                "pass" : "passA"
        },
        {
                "quota" : "2;poolB:portB",
                "user" : "usernameB",
                "pass" : "passB"
        }
]


---
LOGGING

BFGMiner will log to stderr if it detects stderr is being redirected to a file.
To enable logging simply add 2>logfile.txt to your command line and logfile.txt
will contain the logged output at the log level you specify (normal, verbose,
debug etc.)

In other words if you would normally use:
./bfgminer -o xxx -u yyy -p zzz
if you use
./bfgminer -o xxx -u yyy -p zzz 2>logfile.txt
it will log to a file called logfile.txt and otherwise work the same.

There is also the -m option on linux which will spawn a command of your choice
and pipe the output directly to that command.

The WorkTime details 'debug' option adds details on the end of each line
displayed for Accepted or Rejected work done. An example would be:

 <-00000059.ed4834a3 M:X D:1.0 G:17:02:38:0.405 C:1.855 (2.995) W:3.440 (0.000) S:0.461 R:17:02:47

The first 2 hex codes are the previous block hash, the rest are reported in
seconds unless stated otherwise:
The previous hash is followed by the getwork mode used M:X where X is one of
P:Pool, T:Test Pool, L:LP or B:Benchmark,
then D:d.ddd is the difficulty required to get a share from the work,
then G:hh:mm:ss:n.nnn, which is when the getwork or LP was sent to the pool and
the n.nnn is how long it took to reply,
followed by 'O' on its own if it is an original getwork, or 'C:n.nnn' if it was
a clone with n.nnn stating how long after the work was recieved that it was
cloned, (m.mmm) is how long from when the original work was received until work
started,
W:n.nnn is how long the work took to process until it was ready to submit,
(m.mmm) is how long from ready to submit to actually doing the submit, this is
usually 0.000 unless there was a problem with submitting the work,
S:n.nnn is how long it took to submit the completed work and await the reply,
R:hh:mm:ss is the actual time the work submit reply was received

If you start BFGMiner with the --sharelog option, you can get detailed
information for each share found. The argument to the option may be "-" for
standard output (not advisable with the ncurses UI), any valid positive number
for that file descriptor, or a filename.

To log share data to a file named "share.log", you can use either:
./bfgminer --sharelog 50 -o xxx -u yyy -p zzz 50>share.log
./bfgminer --sharelog share.log -o xxx -u yyy -p zzz

For every share found, data will be logged in a CSV (Comma Separated Value)
format:
    timestamp,disposition,target,pool,dev,thr,sharehash,sharedata
For example (this is wrapped, but it's all on one line for real):
    1335313090,reject,
    ffffffffffffffffffffffffffffffffffffffffffffffffffffffff00000000,
    http://localhost:8337,GPU0,0,
    6f983c918f3299b58febf95ec4d0c7094ed634bc13754553ec34fc3800000000,
    00000001a0980aff4ce4a96d53f4b89a2d5f0e765c978640fe24372a000001c5
    000000004a4366808f81d44f26df3d69d7dc4b3473385930462d9ab707b50498
    f681634a4f1f63d01a0cd43fb338000000000080000000000000000000000000
    0000000000000000000000000000000000000000000000000000000080020000

---

RPC API

For RPC API details see the README.RPC file

---

FAQ

Q: Why can't BFGMiner find lib<something> even after I installed it from source
code?
A: On UNIX-like operating systems, you often need to run one or more commands to
reload library caches, such as "ldconfig" or similar. A couple of systems (such
as Fedora) ship with /usr/local/lib missing from their library search path. In
this case, you can usually add it like this:
    echo /usr/local/lib >/etc/ld.so.conf.d/local.conf
Please note that if your libraries installed into lib64 instead of lib, you
should use that in the ld.so config file above instead.

Q: BFGMiner segfaults when I change my shell window size.
A: Older versions of libncurses have a bug to do with refreshing a window
after a size change. Upgrading to a new version of curses will fix it.

Q: I have multiple USB stick devices but I can't get them all to work at once?
A: Very few USB hubs deliver the promised power required to run as many devices
as they fit if all of them draw power from USB. Devices may use up to 2.5 watts
of power (or 4.5 watts for USB 3 devices), and mining USB sticks usually need it
all. You can estimate how much power your USB hub can provide by multiplying its
power supply's output amps by volts (so, if it says 12V 2.5A, you have 12*2.5=
30 watts).

Q: I've confirmed my USB miners are powered sufficiently, but BFGMiner still
is having problems running more than a few at once?
A: Some USB hosts cannot deal with polling as often as miners may need for quick
delivery of shares. On Linux, you can request putting VCOM devices in "high
latency" mode (or rather, disabling the default "low latency" mode) using the
setserial command:
    setserial /dev/ttyUSB0 '^low_latency'
You can further tweak device latency by finding the latency_timer attribute in
sysfs.

Q: I've plugged my devices into my USB hub but nothing shows up?
A: RPis and Windows have incomplete or non-standard USB3 support so they may
never work. It may be possible to get a USB3 hub to work by plugging it into a
USB2 hub.

Q: Can I mine on servers from different networks (eg smartcoin and bitcoin) at
the same time?
A: No, BFGMiner keeps a database of the block it's working on to ensure it does
not work on stale blocks, and having different blocks from two networks would
make it invalidate the work from each other.

Q: Can I configure BFGMiner to mine with different login credentials or pools
for each separate device?
A: No such feature has been implemented to support this.

Q: Can I put multiple pools in the config file?
A: Yes, check the example.conf file. Alternatively, set up everything either on
the command line or via the menu after startup and choose [S]ettings->[W]rite
config file and the file will be loaded one each startup.

Q: The build fails with gcc is unable to build a binary.
A: Remove the "-march=native" component of your CFLAGS as your version of GCC
does not support it.

Q: Can you implement feature X?
A: I can, but time is limited, and people who donate are more likely to get
their feature requests implemented.

Q: Work keeps going to my backup pool even though my primary pool hasn't
failed?
A: BFGMiner checks for conditions where the primary pool is lagging and will
pass some work to the backup servers under those conditions. The reason for
doing this is to try its absolute best to keep the devices working on something
useful and not risk idle periods. You can disable this behaviour with the
option --failover-only.

Q: Is this a virus?
A: As BFGMiner is being packaged with other trojan scripts, some antivirus
software is falsely accusing bfgminer.exe as being the actual virus, rather than
whatever it is being packaged with. If you installed BFGMiner yourself from a
reputable source then you do not have a virus on your computer. Complain to your
antivirus software company. They seem to be flagging even source code from
BFGMiner as malicious now, even though text source files can't do anything by
themselves.

Q: Can you modify the display to include more of one thing in the output and
less of another, or can you change the quiet mode or can you add yet another
output mode?
A: Everyone will always have their own view of what is important to monitor.
The defaults are very sane and I have very little interest in changing this
any further.

Q: Why is my efficiency above/below 1.00?
A: Efficiency simply means how many shares you return for the amount of
bandwidth used. It does not correlate with efficient use of your hardware, and
is a measure of a combination of hardware speed, block luck, pool design and
many other factors.

Q: What are the best parameters to pass for X pool/hardware/device.
A: Virtually always, the DEFAULT parameters give the best results. Most user
defined settings lead to worse performance.

Q: What happened to CPU mining?
A: See README.CPU for more information.

Q: Is there a GUI version?
A: Yes, there are a number of GUI interfaces for BFGMiner:
Name        Website                                Operating system(s)
----        -------                                -------------------
EasyMiner   http://www.butterflylabs.com/drivers/  Android, Linux, Windows
MacMiner    http://fabulouspanda.co.uk/macminer/   Mac
MultiMiner  http://www.multiminerapp.com/          Linux, Mac, Windows (.NET)

Q: Is there a "bare-metal" version?
A: Yes, there are a few dedicated mining operating systems built on BFGMiner:
Name        Website                              Hardware
----        -------                              --------
Controla    http://hashra.com/support            Raspberry Pi
MinePeon    http://mineforeman.com/minepeon/     BeagleBone Black, Raspberry Pi
Minera      http://getminera.com/                Raspberry Pi
PiMP        http://getpimp.org/                  x86

Q: I'm having an issue. What debugging information should I provide?
A: Start BFGMiner with your regular commands and add -D -T --verbose and provide
the full startup output and a summary of your hardware, operating system, and if
applicable, ATI driver version and ATI stream version.

Q: Why isn't BFGMiner performing well or working on my Raspberry Pi?
A: Raspberry Pis have hardware defect(s) which affect USB devices to varying
degrees. Some devices will never be able to work on them, some work fine, and
some require hacks to workaround the problem. One common workaround is to add
the dwc_otg.speed=1 parameter to /boot/cmdline.txt. Note that this will slow
down the USB bus to USB 1.1 speeds, which also affects network bandwidth since
the Raspberry Pi uses a USB network interface. You may wish to consider
upgrading to a BeagleBone or UDOO controller.

Q: Can I mine with BFGMiner on a Mac?
A: BFGMiner will compile on OS X, but the performance of GPU mining is
compromised due to the OpenCL implementation on OS X, there is no temperature or
fanspeed monitoring and the cooling design of most Macs, despite having
powerful GPUs, will usually not cope with constant usage leading to a high risk
of thermal damage. It is highly recommended not to mine on a Mac unless it is
with an external USB device.

Q: My network gets slower and slower and then dies for a minute?
A; Try the --net-delay option if you are on a getwork or GBT server.

Q: How do I tune for P2Pool?
A: P2Pool has very rapid expiration of work and new blocks, it is suggested you
decrease intensity by 1 from your optimal value, and decrease GPU threads to 1
with --set-device OCL:threads=1. It is also recommended to use --failover-only
since the work is effectively like a different block chain. If mining with a
Mini Rig, it is worth adding the --bfl-range option.

Q: I run PHP on windows to access the API with the example miner.php. Why does
it fail when php is installed properly but I only get errors about Sockets not
working in the logs?
A: Please check http://us.php.net/manual/en/sockets.installation.php

Q: What is a PGA?
A: At the moment, BFGMiner supports 5 FPGAs: BitForce, Icarus, ModMiner, X6500,
and ZTEX.
They are Field-Programmable Gate Arrays that have been programmed to do Bitcoin
mining. Since the acronym needs to be only 3 characters, the "Field-" part has
been skipped. "PGA" is also used for devices built with Application-Specific
Integrated Circuits (ASICs).

Q: What is an ASIC?
A: They are Application Specific Integrated Circuit devices and provide the
highest performance per unit power due to being dedicated to only one purpose.

Q: How do I get my BFL/Icarus/Lancelot/Cairnsmore device to auto-recognise?
A: On Linux, if the /dev/ttyUSB* devices don't automatically appear, the only
thing that needs to be done is to load the driver for them:
  BitForce:   sudo modprobe ftdi_sio vendor=0x0403 product=0x6014
  Erupter:    sudo modprobe cp210x   vendor=0x10c4 product=0xea60
  Icarus:     sudo modprobe pl2303   vendor=0x067b product=0x0230
  Lancelot:   sudo modprobe ftdi_sio vendor=0x0403 product=0x6001
  Cairnsmore: sudo modprobe ftdi_sio vendor=0x0403 product=0x8350
On some systems you must manally install the driver required for the device.
OpenWrt drivers (install with opkg):
  FTDI:       kmod-usb-serial-ftdi
  Erupter:    kmod-usb-serial-cp210x
  Icarus:     kmod-usb-serial-pl2303
Windows drivers:
  FTDI:       http://www.ftdichip.com/Drivers/VCP.htm
  Erupter:    http://www.silabs.com/products/mcu/pages/usbtouartbridgevcpdrivers.aspx
  Icarus:     http://prolificusa.com/pl-2303hx-drivers/

Q: I ran cgminer, and now BFGMiner doesn't work!
A: cgminer has its own non-standard implementations of the drivers for most USB
devices, and requires you to replace the official drivers with WinUSB on Windows
(usually using Zadig). Before you can use BFGMiner, you will need to restore the
original driver. Uninstalling the device (and WinUSB driver) from Device Manager
and re-plugging it will usually trigger driver re-installation to the default
drivers.

Q: On Linux I can see the /dev/ttyUSB* devices, but BFGMiner can't mine on them?
A: Make sure you have the required privileges to access the /dev/ttyUSB*
devices:
 sudo ls -las /dev/ttyUSB*
will give output like:
 0 crw-rw---- 1 root video   188, 0 2012-09-11 13:49 /dev/ttyUSB0
This means your account must have the group 'video' or root privileges.
To permanently give your account the 'video' group:
 sudo usermod -G video -a `whoami`
Then logout and back in again.

Q: Can I mine scrypt with FPGAs or ASICs?
A: BFGMiner supports scrypt mining with GridSeed GC3355 ASICs, using either
DualMiner USB sticks or the 5-chip orb.

Q: Why does BFGMiner show a fractional difficulty when mining scrypt?
A: BFGMiner consistently uses pdiff measurement for difficulty everywhere,
rather than other measurements that may exist. For scrypt, pdiff 1 is very
difficult, and higher get exponentially harder. It is unlikely you will want to
use pdiff 1+ with scrypt any time soon.

Q: What is stratum and how do I use it?
A: Stratum is a protocol designed to reduce resources for mining pools at the
cost of keeping the miner in the dark and blindly transferring his mining
authority to the pool. It is a return to the problems of the old centralized
"getwork" protocol, but capable of scaling to hardware of any speed like the
standard GBT protocol. If a pool uses stratum instead of GBT, BFGMiner will
automatically detect it and switch to the support as advertised if it can.
Stratum uses direct TCP connections to the pool and thus it will NOT currently
work through a http proxy but will work via a socks proxy if you need to use
one. If you input the stratum port directly into your configuration, or use the
special prefix "stratum+tcp://" instead of "http://", BFGMiner will ONLY try to
use stratum protocol mining.

Q: Why don't the statistics add up: Accepted, Rejected, Stale, Hardware Errors,
Diff1 Work, etc. when mining greater than 1 difficulty shares?
A: As an example, if you look at 'Difficulty Accepted' in the RPC API, the number
of difficulty shares accepted does not usually exactly equal the amount of work
done to find them. If you are mining at 8 difficulty, then you would expect on
average to find one 8 difficulty share, per 8 single difficulty shares found.
However, the number is actually random and converges over time as it is an
average, not an exact value, thus you may find more or less than the expected
average.

---

This code is provided entirely free of charge by the programmer in his spare
time so donations would be greatly appreciated. Please consider donating to the
address below.

Luke-Jr <luke-jr+bfgminer@utopios.org>
1QATWksNFGeUJCWBrN4g6hGM178Lovm7Wh
